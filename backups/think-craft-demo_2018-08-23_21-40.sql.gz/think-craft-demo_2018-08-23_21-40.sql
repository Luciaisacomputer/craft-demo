-- MySQL dump 10.16  Distrib 10.1.35-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: craft
-- ------------------------------------------------------
-- Server version	10.1.35-MariaDB-1~bionic

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `craft_assetfiles`
--

DROP TABLE IF EXISTS `craft_assetfiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_assetfiles` (
  `id` int(11) NOT NULL,
  `sourceId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kind` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assetfiles_filename_folderId_unq_idx` (`filename`,`folderId`),
  KEY `craft_assetfiles_sourceId_fk` (`sourceId`),
  KEY `craft_assetfiles_folderId_fk` (`folderId`),
  CONSTRAINT `craft_assetfiles_folderId_fk` FOREIGN KEY (`folderId`) REFERENCES `craft_assetfolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assetfiles_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assetfiles_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_assetsources` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_assetfiles`
--

LOCK TABLES `craft_assetfiles` WRITE;
/*!40000 ALTER TABLE `craft_assetfiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_assetfiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_assetfolders`
--

DROP TABLE IF EXISTS `craft_assetfolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_assetfolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `sourceId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assetfolders_name_parentId_sourceId_unq_idx` (`name`,`parentId`,`sourceId`),
  KEY `craft_assetfolders_parentId_fk` (`parentId`),
  KEY `craft_assetfolders_sourceId_fk` (`sourceId`),
  CONSTRAINT `craft_assetfolders_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `craft_assetfolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assetfolders_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_assetsources` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_assetfolders`
--

LOCK TABLES `craft_assetfolders` WRITE;
/*!40000 ALTER TABLE `craft_assetfolders` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_assetfolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_assetindexdata`
--

DROP TABLE IF EXISTS `craft_assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sourceId` int(10) NOT NULL,
  `offset` int(10) NOT NULL,
  `uri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recordId` int(10) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assetindexdata_sessionId_sourceId_offset_unq_idx` (`sessionId`,`sourceId`,`offset`),
  KEY `craft_assetindexdata_sourceId_fk` (`sourceId`),
  CONSTRAINT `craft_assetindexdata_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_assetsources` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_assetindexdata`
--

LOCK TABLES `craft_assetindexdata` WRITE;
/*!40000 ALTER TABLE `craft_assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_assetsources`
--

DROP TABLE IF EXISTS `craft_assetsources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_assetsources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `fieldLayoutId` int(10) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assetsources_name_unq_idx` (`name`),
  UNIQUE KEY `craft_assetsources_handle_unq_idx` (`handle`),
  KEY `craft_assetsources_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_assetsources_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_assetsources`
--

LOCK TABLES `craft_assetsources` WRITE;
/*!40000 ALTER TABLE `craft_assetsources` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_assetsources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_assettransformindex`
--

DROP TABLE IF EXISTS `craft_assettransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fileId` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sourceId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT NULL,
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_assettransformindex_sourceId_fileId_location_idx` (`sourceId`,`fileId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_assettransformindex`
--

LOCK TABLES `craft_assettransformindex` WRITE;
/*!40000 ALTER TABLE `craft_assettransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_assettransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_assettransforms`
--

DROP TABLE IF EXISTS `craft_assettransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mode` enum('stretch','fit','crop') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'center-center',
  `height` int(10) DEFAULT NULL,
  `width` int(10) DEFAULT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quality` int(10) DEFAULT NULL,
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assettransforms_name_unq_idx` (`name`),
  UNIQUE KEY `craft_assettransforms_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_assettransforms`
--

LOCK TABLES `craft_assettransforms` WRITE;
/*!40000 ALTER TABLE `craft_assettransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_assettransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_categories`
--

DROP TABLE IF EXISTS `craft_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_categories_groupId_fk` (`groupId`),
  CONSTRAINT `craft_categories_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_categories_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_categories`
--

LOCK TABLES `craft_categories` WRITE;
/*!40000 ALTER TABLE `craft_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_categorygroups`
--

DROP TABLE IF EXISTS `craft_categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hasUrls` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `template` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_categorygroups_name_unq_idx` (`name`),
  UNIQUE KEY `craft_categorygroups_handle_unq_idx` (`handle`),
  KEY `craft_categorygroups_structureId_fk` (`structureId`),
  KEY `craft_categorygroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_categorygroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_categorygroups_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_categorygroups`
--

LOCK TABLES `craft_categorygroups` WRITE;
/*!40000 ALTER TABLE `craft_categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_categorygroups_i18n`
--

DROP TABLE IF EXISTS `craft_categorygroups_i18n`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_categorygroups_i18n` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `urlFormat` text COLLATE utf8_unicode_ci,
  `nestedUrlFormat` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_categorygroups_i18n_groupId_locale_unq_idx` (`groupId`,`locale`),
  KEY `craft_categorygroups_i18n_locale_fk` (`locale`),
  CONSTRAINT `craft_categorygroups_i18n_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_categorygroups_i18n_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_categorygroups_i18n`
--

LOCK TABLES `craft_categorygroups_i18n` WRITE;
/*!40000 ALTER TABLE `craft_categorygroups_i18n` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_categorygroups_i18n` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_content`
--

DROP TABLE IF EXISTS `craft_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field_body` text COLLATE utf8_unicode_ci,
  `field_date` datetime DEFAULT NULL,
  `field_locationName` text COLLATE utf8_unicode_ci,
  `field_address` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_content_elementId_locale_unq_idx` (`elementId`,`locale`),
  KEY `craft_content_title_idx` (`title`),
  KEY `craft_content_locale_fk` (`locale`),
  CONSTRAINT `craft_content_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_content_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_content`
--

LOCK TABLES `craft_content` WRITE;
/*!40000 ALTER TABLE `craft_content` DISABLE KEYS */;
INSERT INTO `craft_content` VALUES (1,1,'en_us',NULL,NULL,NULL,NULL,NULL,'2018-08-20 21:51:09','2018-08-20 21:51:09','2e2f2ee8-28a5-4e53-a4a9-6d79d9325ecf'),(2,2,'en_us','Welcome to Localhost!','<p>It’s true, this site doesn’t have a whole lot of content yet, but don’t worry. Our web developers have just installed the CMS, and they’re setting things up for the content editors this very moment. Soon Localhost will be an oasis of fresh perspectives, sharp analyses, and astute opinions that will keep you coming back again and again.</p>',NULL,NULL,NULL,'2018-08-20 21:51:10','2018-08-23 01:30:08','083a646c-a4e4-48bd-9f61-f5bd82e669d5'),(3,3,'en_us','We just installed Craft!','<p>Craft is the CMS that’s powering Localhost. It’s beautiful, powerful, flexible, and easy-to-use, and it’s made by Pixel &amp; Tonic. We can’t wait to dive in and see what it’s capable of!</p><!--pagebreak--><p>This is even more captivating content, which you couldn’t see on the News index page because it was entered after a Page Break, and the News index template only likes to show the content on the first page.</p><p>Craft: a nice alternative to Word, if you’re making a website.</p>',NULL,NULL,NULL,'2018-08-20 21:51:10','2018-08-20 21:51:10','e7d490ce-0dbe-493c-8727-15ee3ce00c54'),(4,4,'en_us','Cheese Day 2018',NULL,'2018-08-24 02:00:00','Think Space','123 Think Space','2018-08-22 02:12:53','2018-08-24 01:12:54','32d1e3a4-bdb5-48e0-85e6-fc091c146be7'),(5,5,'en_us','PWA Meetup',NULL,'2018-08-31 02:00:00','Think Space','123 Think Space','2018-08-22 02:13:12','2018-08-24 01:16:50','2b62436f-20fd-4edb-afff-1f688dbf4a69'),(6,6,'en_us','Urban Axes',NULL,'2018-08-31 22:00:00','Think Space','123 Think Space','2018-08-22 02:13:45','2018-08-24 01:20:29','f5042973-8567-4411-a717-a5639a20d387'),(7,7,'en_us','All Your Dreams Came True Overnight With Progressive Web Applications','<p>With the <a href=\"https://www.apple.com/newsroom/2018/03/ios-11-3-is-available-today/\">release of the newest version of Apple’s iOS</a>, a four-year-old technology called <a href=\"https://developers.google.com/web/progressive-web-apps/\">Progressive Web Applications</a> (PWAs) just became an overnight success.\n</p>\n<p>Like the term <a href=\"http://adaptivepath.org/ideas/ajax-new-approach-web-applications/\">“Ajax” in 2005</a>, the term “Progressive Web Application” is a buzzword applied to a handful of new technologies. Specifically, it’s the way that web browsers on desktop and mobile devices will now <em>grant their native-application powers to websites</em>.\n</p>\n<p>Chrome and Firefox users on Android and Windows (yes, on the desktop!) have had <a href=\"https://caniuse.com/#feat=serviceworkers\">access to these features for some time</a>. Now that they’ve been released to iOS, those Progressive Web Application superpowers will quickly be <em>everywhere</em>!\n</p>\n<p>And that means opportunities for you.\n</p>\n<h2>WHAT CAN MY SITE DO ONCE IT’S A PROGRESSIVE WEB APP?</h2>\n<p>Once your site is running over a secure connection and you’ve added two pieces of code, you can:\n</p>\n<ul><li>Make your website available offline.\n</li><li>Make your site run just as quickly over 4G as it does over wifi.\n</li><li>Get your site onto users’ home screens <em>without</em> putting them through the app-store process.\n</li><li>Did we mention the app store process? While you’re at it, you can save yourself the three weeks of hair-pulling since you won’t need app-store approval.\n</li><li>Do all of the above using a <em>web</em> tools, using <em>web</em> skillsets, on a <em>web</em> budget and a <em>web</em> timeline. All managed in <em>just one code base</em>. Think how simple your Trello boards will get!\n</li></ul><p>Soon, PWAs will be able to access Bluetooth. That will completely reshape how the Internet of Things works with the average user. <em>And that’s just getting started.</em>\n</p>\n<h3>SOUND INTERESTING? JOIN US AT THE PHILLY PWA MEETUP!</h3>\n<p>Maybe you’re a business stakeholder that wants to know how using Progressive Web Apps can reduce the cost of developing applications. Maybe you’re a product owner that dreams of releasing features with just one developer team instead of three. And maybe you’re a developer that wants to play with the big new box of toys that PWAs provide. Please join us at the <a href=\"https://www.meetup.com/PWA-Philly/\">Philly Progressive Web App meetup</a>, and let’s explore what’s possible together!\n</p>',NULL,NULL,NULL,'2018-08-22 03:23:57','2018-08-22 03:39:28','8566358a-732c-420d-97e4-51d89be9b42e'),(8,8,'en_us','The Last Mile in Website Security: Usability','<p>A thousand critical details go into making a website secure. But we often overlook the most critical piece of security: usability.</p>\n<p>“Security at the expense of usability, comes at the expense of security.” – AviD, user on Stack Exchange</p>\n<p>Think about all the times you’ve seen someone write down their password and stick it on their monitor. If the best security is too hard to use, people will look for ways to bypass it. The best security is the security your users will actually use.</p>',NULL,NULL,NULL,'2018-08-22 03:24:06','2018-08-22 03:43:56','709180b2-bbed-41d1-a2ec-a36ca540d989'),(9,9,'en_us','Data Visualization, and Identifying The True Challenge Within The Question','<p>It started when a developer on a client’s team approached me with a question: “Hey, you know D3.js right? Could you help us visualize some data?”</p>\n<p>“Of course,” I said. That’s one of the reasons they brought us in, after all! “What are you trying to achieve?” Asking one seemingly simple question was the difference between delivering the requested solution and implementing a solution that went beyond the request to expose even more useful information.\n</p>\n<p>We were in the middle of reskinning a legacy application built in a tech stack from a bygone era. Most of the codebase was decades old; a gnarly, tangled rubber-band ball of dependencies—the epitome of what developers refer to as “spaghetti code,” full of bad practices.\n</p>\n<p>One notable challenge affected us daily: there was no file naming convention, and often there were duplicate files in different folders, so no one knew where the definitive version of any particular asset resided without a lot of hunting and guessing. Every time a change was required, work started with spelunking into the code base—or even worse, searching the database. It was the proverbial haystack, and we were always looking for a hay-colored needle.\n</p>\n<p>For this and other reasons, the client developer recognized what we were up against. Any development task inevitably led to the questions, “What is the risk of this change? What else will be affected?”\n</p>\n<p>The team set out to make a spreadsheet of all the dependencies. File A depends on File B, File B depends on File D, etc. But once we had compiled all of that data, it still wasn’t useful to humans. That’s when I was asked, “You know D3.js, right?”\n</p>\n<p>D3.js is a JavaScript-based data visualization library that we leverage on a fairly regular basis. The hope was that I could visualize all these dependencies—about 3,519 of them—to paint a picture of what we already knew for the rest of the organization: things were a mess.\n</p>\n<p>The pivotal moment came from a seemingly simple question. Before just following orders, I asked, “What are you trying to achieve?” We spoke about what the data was, what sort of questions we’d want to answer, and I had an epiphany: D3 is a great tool for custom visualizations (and as in this case, is often requested/prescribed by the client at the outset), but like all tools, you need to know when to use it.\n</p>\n<p>Some time ago, I was introduced to a tool called Neo4j, a <a href=\"https://en.wikipedia.org/wiki/Graph_database\">Graph Database</a> engine. I had barely tinkered with it, but I understood the general concept. Graph databases are primarily concerned with storing two things: nodes (“things”) and relationships. Any point of data is a node, and how it relates to other nodes is, well, the relationship. Graph databases are perfect for asking questions about how things are related, and how relationships are shared.\n</p>\n<p>So a graph database seemed like the direction to go: instead of a simple visualization generated after several hours of development, we had useful, pretty graphs we could query within minutes.\n</p>\n<p>We could ask all kinds of questions: “What files have the most relationships? What files have no relationships? What files include ExampleFile.cfm?” Suddenly, we had a map. Because of the nature of Neo4j, we could easily add additional data as we wanted to ask more questions: “What files use this global variable? What files make direct database calls?” And as a bonus, all the visualizations are done with… you guessed it… D3, right out of the box.\n</p>\n<p>Say we want to make a change that involves a particular file, but we need to know the impact it will have on the current codebase?\n</p>\n<p><strong>We can ask Neo4j “Hey, what files rely on ‘exampleFile.cfm’?” :</strong>\n</p>\n<p><img src=\"https://3vwizk2qtr8l3diwrm3r2ba0-wpengine.netdna-ssl.com/wp-content/uploads/2018/01/graphExample.gif\" style=\"margin-right:auto;margin-left:auto;\" alt=\"graphExample.gif\" /></p>\n<p><strong>Or “Show us all the relationships in our application”:</strong>\n</p>\n<p><img src=\"https://3vwizk2qtr8l3diwrm3r2ba0-wpengine.netdna-ssl.com/wp-content/uploads/2018/01/allGraph.gif\" style=\"margin-right:auto;margin-left:auto;\" alt=\"allGraph.gif\" /></p>\n<p>Instead of a static visualization, we have our data in a queryable format!\n</p>\n<p>The most important thing I learned is to always get to the root of what the client is trying to do. “What are you trying to achieve?” is a powerful question, and can be the difference between a satisfactory outcome and a robust solution for the client. When exposed to the dev team at large, they were immediately inspired to ask more questions of the graph database. Instead of a good-enough tool, we leveraged a tool that got us even closer to making our case and solving the issue.\n</p>\n<p>The whole journey was a good reminder: expand your horizons outside your discipline, and always look for the right problem to solve—not necessarily the literal question you’re presented with. This approach leads to solutions that exceed expectations.</p>',NULL,NULL,NULL,'2018-08-22 03:24:28','2018-08-22 03:41:03','54e62738-ec74-45e1-9945-fefd0c50a1eb');
/*!40000 ALTER TABLE `craft_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_deprecationerrors`
--

DROP TABLE IF EXISTS `craft_deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fingerprint` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `line` smallint(6) unsigned NOT NULL,
  `class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `method` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `templateLine` smallint(6) unsigned DEFAULT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `traces` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_deprecationerrors_key_fingerprint_unq_idx` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_deprecationerrors`
--

LOCK TABLES `craft_deprecationerrors` WRITE;
/*!40000 ALTER TABLE `craft_deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_elementindexsettings`
--

DROP TABLE IF EXISTS `craft_elementindexsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_elementindexsettings_type_unq_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_elementindexsettings`
--

LOCK TABLES `craft_elementindexsettings` WRITE;
/*!40000 ALTER TABLE `craft_elementindexsettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_elementindexsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_elements`
--

DROP TABLE IF EXISTS `craft_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `archived` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_elements_type_idx` (`type`),
  KEY `craft_elements_enabled_idx` (`enabled`),
  KEY `craft_elements_archived_dateCreated_idx` (`archived`,`dateCreated`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_elements`
--

LOCK TABLES `craft_elements` WRITE;
/*!40000 ALTER TABLE `craft_elements` DISABLE KEYS */;
INSERT INTO `craft_elements` VALUES (1,'User',1,0,'2018-08-20 21:51:09','2018-08-20 21:51:09','ffdecae1-abb2-4a42-b533-3f0268dfa729'),(2,'Entry',1,0,'2018-08-20 21:51:10','2018-08-23 01:30:08','4026456c-2fc2-4f11-a7da-537b70853960'),(3,'Entry',1,0,'2018-08-20 21:51:10','2018-08-20 21:51:10','725b67b3-bed6-4a72-8a64-25d426b01e07'),(4,'Entry',1,0,'2018-08-22 02:12:53','2018-08-24 01:12:54','d2c7e8c0-80cb-4e7a-9df5-dcc7f2591f6e'),(5,'Entry',1,0,'2018-08-22 02:13:12','2018-08-24 01:16:50','f04248f9-2c9d-4e90-8ddf-03e2c9cec11b'),(6,'Entry',1,0,'2018-08-22 02:13:45','2018-08-24 01:20:29','84b41f29-6f99-48bf-b131-21d1480b9958'),(7,'Entry',1,0,'2018-08-22 03:23:57','2018-08-22 03:39:28','a4d97903-84a8-406c-8d35-f70123da5770'),(8,'Entry',1,0,'2018-08-22 03:24:06','2018-08-22 03:43:56','27670d27-d82c-4ecd-ab96-0b4c1fd662fe'),(9,'Entry',1,0,'2018-08-22 03:24:28','2018-08-22 03:41:03','7cfbb4e9-e230-4dd4-8cda-f3f483f1deda');
/*!40000 ALTER TABLE `craft_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_elements_i18n`
--

DROP TABLE IF EXISTS `craft_elements_i18n`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_elements_i18n` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_elements_i18n_elementId_locale_unq_idx` (`elementId`,`locale`),
  UNIQUE KEY `craft_elements_i18n_uri_locale_unq_idx` (`uri`,`locale`),
  KEY `craft_elements_i18n_slug_locale_idx` (`slug`,`locale`),
  KEY `craft_elements_i18n_enabled_idx` (`enabled`),
  KEY `craft_elements_i18n_locale_fk` (`locale`),
  CONSTRAINT `craft_elements_i18n_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_elements_i18n_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_elements_i18n`
--

LOCK TABLES `craft_elements_i18n` WRITE;
/*!40000 ALTER TABLE `craft_elements_i18n` DISABLE KEYS */;
INSERT INTO `craft_elements_i18n` VALUES (1,1,'en_us','',NULL,1,'2018-08-20 21:51:09','2018-08-20 21:51:09','5016385c-261e-4051-aba5-f4b8e033169a'),(2,2,'en_us','homepage','__home__',1,'2018-08-20 21:51:10','2018-08-23 01:30:08','f76c6a7d-2b88-4b45-adee-4412b90f78d1'),(3,3,'en_us','we-just-installed-craft','news/2018/we-just-installed-craft',1,'2018-08-20 21:51:10','2018-08-20 21:51:10','0d363f98-516b-43a9-b213-acf5e210b8c2'),(4,4,'en_us','cheese-day-2018','event/cheese-day-2018',1,'2018-08-22 02:12:53','2018-08-24 01:12:54','7ae31340-5d15-4e7b-a180-accf3231ed14'),(5,5,'en_us','pwa-meetup','event/pwa-meetup',1,'2018-08-22 02:13:12','2018-08-24 01:16:50','ca2ce4e3-d321-48c1-9bb1-417d799dc24b'),(6,6,'en_us','urban-axes','event/urban-axes',1,'2018-08-22 02:13:45','2018-08-24 01:20:29','5b66a312-8025-449e-987e-ff36cf2c6dd3'),(7,7,'en_us','all-your-dreams-came-true-overnight-with-progressive-web-applications','news/2018/all-your-dreams-came-true-overnight-with-progressive-web-applications',1,'2018-08-22 03:23:57','2018-08-22 03:39:28','1e84943e-84d4-4c9c-933f-0c85bcea96e7'),(8,8,'en_us','the-last-mile-in-website-security-usability','news/2018/the-last-mile-in-website-security-usability',1,'2018-08-22 03:24:06','2018-08-22 03:43:56','5b348721-20dc-44ef-8c67-db0579b68494'),(9,9,'en_us','data-visualization-and-identifying-the-true-challenge-within-the-question','news/2018/data-visualization-and-identifying-the-true-challenge-within-the-question',1,'2018-08-22 03:24:28','2018-08-22 03:41:03','ab5e8f16-e4d3-4b03-b19b-492b78f0822d');
/*!40000 ALTER TABLE `craft_elements_i18n` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_emailmessages`
--

DROP TABLE IF EXISTS `craft_emailmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_emailmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` char(150) COLLATE utf8_unicode_ci NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_emailmessages_key_locale_unq_idx` (`key`,`locale`),
  KEY `craft_emailmessages_locale_fk` (`locale`),
  CONSTRAINT `craft_emailmessages_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_emailmessages`
--

LOCK TABLES `craft_emailmessages` WRITE;
/*!40000 ALTER TABLE `craft_emailmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_emailmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_entries`
--

DROP TABLE IF EXISTS `craft_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `typeId` int(11) DEFAULT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entries_sectionId_idx` (`sectionId`),
  KEY `craft_entries_typeId_idx` (`typeId`),
  KEY `craft_entries_postDate_idx` (`postDate`),
  KEY `craft_entries_expiryDate_idx` (`expiryDate`),
  KEY `craft_entries_authorId_fk` (`authorId`),
  CONSTRAINT `craft_entries_authorId_fk` FOREIGN KEY (`authorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_entries`
--

LOCK TABLES `craft_entries` WRITE;
/*!40000 ALTER TABLE `craft_entries` DISABLE KEYS */;
INSERT INTO `craft_entries` VALUES (2,1,1,NULL,'2018-08-23 01:30:08',NULL,'2018-08-20 21:51:10','2018-08-23 01:30:08','8937c3d4-2dbb-468c-9bed-1a30d6d28a77'),(3,2,2,1,'2018-08-20 21:51:10',NULL,'2018-08-20 21:51:10','2018-08-20 21:51:10','d195455e-4a5e-4916-af75-2949b2d3deab'),(4,3,3,1,'2018-08-22 02:12:00',NULL,'2018-08-22 02:12:53','2018-08-24 01:12:54','a108e026-cbe6-4f51-b037-75a931de003b'),(5,3,3,1,'2018-08-22 02:13:00',NULL,'2018-08-22 02:13:12','2018-08-24 01:16:50','b6a9cc60-b5c4-4537-9e38-11d7139d9319'),(6,3,3,1,'2018-08-22 02:13:00',NULL,'2018-08-22 02:13:45','2018-08-24 01:20:29','1762b99d-c638-4001-8bbc-5d6ceed63107'),(7,2,2,1,'2018-08-22 03:23:00',NULL,'2018-08-22 03:23:57','2018-08-22 03:39:28','06d85744-a992-49f4-95da-c13f32fc9bca'),(8,2,2,1,'2018-08-22 03:24:00',NULL,'2018-08-22 03:24:06','2018-08-22 03:43:56','20f66132-8a89-4986-a614-3ed1dcd4dc21'),(9,2,2,1,'2018-08-22 03:24:00',NULL,'2018-08-22 03:24:28','2018-08-22 03:41:03','81a111a9-c823-4f7b-bc69-7e7eaaa498ed');
/*!40000 ALTER TABLE `craft_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_entrydrafts`
--

DROP TABLE IF EXISTS `craft_entrydrafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_entrydrafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notes` tinytext COLLATE utf8_unicode_ci,
  `data` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entrydrafts_entryId_locale_idx` (`entryId`,`locale`),
  KEY `craft_entrydrafts_sectionId_fk` (`sectionId`),
  KEY `craft_entrydrafts_creatorId_fk` (`creatorId`),
  KEY `craft_entrydrafts_locale_fk` (`locale`),
  CONSTRAINT `craft_entrydrafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_entrydrafts_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_entrydrafts`
--

LOCK TABLES `craft_entrydrafts` WRITE;
/*!40000 ALTER TABLE `craft_entrydrafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_entrydrafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_entrytypes`
--

DROP TABLE IF EXISTS `craft_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hasTitleField` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `titleLabel` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Title',
  `titleFormat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_entrytypes_name_sectionId_unq_idx` (`name`,`sectionId`),
  UNIQUE KEY `craft_entrytypes_handle_sectionId_unq_idx` (`handle`,`sectionId`),
  KEY `craft_entrytypes_sectionId_fk` (`sectionId`),
  KEY `craft_entrytypes_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_entrytypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entrytypes_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_entrytypes`
--

LOCK TABLES `craft_entrytypes` WRITE;
/*!40000 ALTER TABLE `craft_entrytypes` DISABLE KEYS */;
INSERT INTO `craft_entrytypes` VALUES (1,1,3,'Home','homepage',1,'Title',NULL,1,'2018-08-20 21:51:10','2018-08-23 01:28:56','d95dfc73-8871-4e99-9a02-209dcc51a4fc'),(2,2,5,'News','news',1,'Title',NULL,1,'2018-08-20 21:51:10','2018-08-20 21:51:10','38af09ab-769f-4839-9492-1e93f5d95266'),(3,3,8,'Event','event',1,'Title',NULL,1,'2018-08-22 01:53:05','2018-08-24 01:06:28','fa92348d-961b-48c1-8ff0-029786f75df9'),(4,4,9,'Employees','employees',1,'Title',NULL,1,'2018-08-24 01:25:58','2018-08-24 01:25:58','6e0b1d09-8f0f-4e6b-9664-fe8019be9d7a');
/*!40000 ALTER TABLE `craft_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_entryversions`
--

DROP TABLE IF EXISTS `craft_entryversions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_entryversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `num` smallint(6) unsigned NOT NULL,
  `notes` tinytext COLLATE utf8_unicode_ci,
  `data` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entryversions_entryId_locale_idx` (`entryId`,`locale`),
  KEY `craft_entryversions_sectionId_fk` (`sectionId`),
  KEY `craft_entryversions_creatorId_fk` (`creatorId`),
  KEY `craft_entryversions_locale_fk` (`locale`),
  CONSTRAINT `craft_entryversions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entryversions_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entryversions_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_entryversions_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_entryversions`
--

LOCK TABLES `craft_entryversions` WRITE;
/*!40000 ALTER TABLE `craft_entryversions` DISABLE KEYS */;
INSERT INTO `craft_entryversions` VALUES (1,2,1,1,'en_us',1,NULL,'{\"typeId\":\"1\",\"authorId\":null,\"title\":\"Homepage\",\"slug\":\"homepage\",\"postDate\":1534801870,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":[]}','2018-08-20 21:51:10','2018-08-20 21:51:10','2e366064-8ac7-4e0e-8136-46bc71310379'),(2,2,1,1,'en_us',2,NULL,'{\"typeId\":null,\"authorId\":null,\"title\":\"Welcome to Localhost!\",\"slug\":\"homepage\",\"postDate\":1534801870,\"expiryDate\":null,\"enabled\":\"1\",\"parentId\":null,\"fields\":{\"1\":\"<p>It\\u2019s true, this site doesn\\u2019t have a whole lot of content yet, but don\\u2019t worry. Our web developers have just installed the CMS, and they\\u2019re setting things up for the content editors this very moment. Soon Localhost will be an oasis of fresh perspectives, sharp analyses, and astute opinions that will keep you coming back again and again.<\\/p>\"}}','2018-08-20 21:51:10','2018-08-20 21:51:10','7f9c4560-22ac-4b35-a63e-78744707e6bd'),(3,3,2,1,'en_us',1,NULL,'{\"typeId\":\"2\",\"authorId\":\"1\",\"title\":\"We just installed Craft!\",\"slug\":\"we-just-installed-craft\",\"postDate\":1534801870,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":[]}','2018-08-20 21:51:10','2018-08-20 21:51:10','7fd63225-4e95-46af-8cca-b3f0cb26d388'),(4,4,3,1,'en_us',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"Cheese Day 2018\",\"slug\":\"cheese-day-2018\",\"postDate\":1534903973,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":[]}','2018-08-22 02:12:53','2018-08-22 02:12:53','c9832e24-eddf-43b9-96df-0c8669cfc7b5'),(5,5,3,1,'en_us',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"PWA Meetup\",\"slug\":\"pwa-meetup\",\"postDate\":1534903992,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":[]}','2018-08-22 02:13:12','2018-08-22 02:13:12','8151f6cc-ef41-441e-aed9-2cb45a371909'),(6,6,3,1,'en_us',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"Urban Axes\",\"slug\":\"urban-axes\",\"postDate\":1534904025,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":[]}','2018-08-22 02:13:45','2018-08-22 02:13:45','7e369f76-46f3-45ca-8f93-fdde22e9b331'),(7,7,2,1,'en_us',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"All Your Dreams Came True Overnight With Progressive Web Applications\",\"slug\":\"all-your-dreams-came-true-overnight-with-progressive-web-applications\",\"postDate\":1534908180,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"1\":\"<p>Body cannot be blank<\\/p>\",\"2\":\"\"}}','2018-08-22 03:23:57','2018-08-22 03:23:57','5f4f922c-186b-48ad-aee9-89963dd9f568'),(8,8,2,1,'en_us',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"The Last Mile in Website Security: Usability\",\"slug\":\"the-last-mile-in-website-security-usability\",\"postDate\":1534908246,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"1\":\"<p>Body cannot be blank<\\/p>\",\"2\":\"\"}}','2018-08-22 03:24:06','2018-08-22 03:24:06','2f76bb29-2e2a-40e7-8ebc-0462fb409ad7'),(9,9,2,1,'en_us',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"Data Visualization, and Identifying The True Challenge Within The Question\",\"slug\":\"data-visualization-and-identifying-the-true-challenge-within-the-question\",\"postDate\":1534908268,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"1\":\"<p>Test<\\/p>\",\"2\":\"\"}}','2018-08-22 03:24:28','2018-08-22 03:24:28','c43cf0fd-78d3-4533-ab6d-6f6e8f2419c4'),(10,7,2,1,'en_us',2,'','{\"typeId\":\"2\",\"authorId\":\"1\",\"title\":\"All Your Dreams Came True Overnight With Progressive Web Applications\",\"slug\":\"all-your-dreams-came-true-overnight-with-progressive-web-applications\",\"postDate\":1534908180,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"1\":\"<p>With the&nbsp;<a href=\\\"https:\\/\\/www.apple.com\\/newsroom\\/2018\\/03\\/ios-11-3-is-available-today\\/\\\">release of the newest version of Apple\\u2019s iOS<\\/a>, a four-year-old technology called&nbsp;<a href=\\\"https:\\/\\/developers.google.com\\/web\\/progressive-web-apps\\/\\\">Progressive Web Applications<\\/a>&nbsp;(PWAs) just became an overnight success.\\r\\n<\\/p>\\r\\n<p>Like the term&nbsp;<a href=\\\"http:\\/\\/adaptivepath.org\\/ideas\\/ajax-new-approach-web-applications\\/\\\">\\u201cAjax\\u201d in 2005<\\/a>, the term \\u201cProgressive Web Application\\u201d is a buzzword applied to a handful of new technologies. Specifically, it\\u2019s the way that web browsers on desktop and mobile devices will now&nbsp;<em>grant their native-application powers to websites<\\/em>.\\r\\n<\\/p>\\r\\n<p>Chrome and Firefox users on Android and Windows (yes, on the desktop!) have had&nbsp;<a href=\\\"https:\\/\\/caniuse.com\\/#feat=serviceworkers\\\">access to these features for some time<\\/a>. Now that they\\u2019ve been released to iOS, those Progressive Web Application superpowers will quickly be&nbsp;<em>everywhere<\\/em>!\\r\\n<\\/p>\\r\\n<p>And that means opportunities for you.\\r\\n<\\/p>\\r\\n<h2>WHAT CAN MY SITE DO ONCE IT\\u2019S A PROGRESSIVE WEB APP?<\\/h2>\\r\\n<p>Once your site is running over a secure connection and you\\u2019ve added two pieces of code, you can:\\r\\n<\\/p>\\r\\n<ul><li>Make your website available offline.\\r\\n<\\/li><li>Make your site run just as quickly over 4G as it does over wifi.\\r\\n<\\/li><li>Get your site onto users\\u2019 home screens&nbsp;<em>without<\\/em>&nbsp;putting them through the app-store process.\\r\\n<\\/li><li>Did we mention the app store process? While you\\u2019re at it, you can save yourself the three weeks of hair-pulling since you won\\u2019t need app-store approval.\\r\\n<\\/li><li>Do all of the above using a&nbsp;<em>web<\\/em>&nbsp;tools, using&nbsp;<em>web<\\/em>&nbsp;skillsets, on a&nbsp;<em>web<\\/em>&nbsp;budget and a&nbsp;<em>web<\\/em>&nbsp;timeline. All managed in&nbsp;<em>just one code base<\\/em>. Think how simple your Trello boards will get!\\r\\n<\\/li><\\/ul>\\r\\n<p>Soon, PWAs will be able to access Bluetooth. That will completely reshape how the Internet of Things works with the average user.&nbsp;<em>And that\\u2019s just getting started.<\\/em>\\r\\n<\\/p>\\r\\n<h3>SOUND INTERESTING? JOIN US AT THE PHILLY PWA MEETUP!<\\/h3>\\r\\n<p>Maybe you\\u2019re a business stakeholder that wants to know how using Progressive Web Apps can reduce the cost of developing applications. Maybe you\\u2019re a product owner that dreams of releasing features with just one developer team instead of three. And maybe you\\u2019re a developer that wants to play with the big new box of toys that PWAs provide. Please join us at the&nbsp;<a href=\\\"https:\\/\\/www.meetup.com\\/PWA-Philly\\/\\\">Philly Progressive Web App meetup<\\/a>, and let\\u2019s explore what\\u2019s possible together!\\r\\n<\\/p>\",\"2\":\"\"}}','2018-08-22 03:39:28','2018-08-22 03:39:28','4574098b-b5e8-49af-a9d6-3a686c47770b'),(11,8,2,1,'en_us',2,'','{\"typeId\":\"2\",\"authorId\":\"1\",\"title\":\"The Last Mile in Website Security: Usability\",\"slug\":\"the-last-mile-in-website-security-usability\",\"postDate\":1534908240,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"1\":\"<p>A thousand critical details go into making a website secure. But we often overlook the most critical piece of security: usability.\\r\\n<\\/p>\\r\\n<blockquote>\\u201cSecurity at the expense of usability, comes at the expense of security.\\u201d \\u2013 AviD, user on Stack Exchange\\r\\n<br><\\/blockquote>\\r\\n<p>Think about all the times you\\u2019ve seen someone write down their password and stick it on their monitor. If the best security is too hard to use, people will look for ways to bypass it. The best security is the security your users will actually use.\\r\\n<img src=\\\"https:\\/\\/3vwizk2qtr8l3diwrm3r2ba0-wpengine.netdna-ssl.com\\/wp-content\\/uploads\\/2017\\/12\\/Security-Usability.jpg\\\" alt=\\\"Security at the cost of usability, comes at the cost of security.\\\" title=\\\"Security at the cost of usability, comes at the cost of security.\\\">\\r\\nHere at Think Company, we spend all day every day thinking about your users\\u2019 experience, and security is a big part of it. Here are some of our thoughts about the interface between security and usability.\\r\\n<\\/p>\\r\\n<h3>BE AWARE OF REUSED PASSWORDS<\\/h3>\\r\\n<p>The average person has roughly 27 logins to remember. Your most security-conscious users have a password manager to make sure that each password is unique. But not all of your users are that security-conscious. Many of your users reuse the same password multiple times&mdash;and attackers are smart enough to know this.\\r\\n<\\/p>\\r\\n<h3>CONSIDER USING TWO-FACTOR AUTHENTICATION<\\/h3>\\r\\n<p>With two-factor authentication, the password (\\u201csomething you know\\u201d) is backed up by a device (\\u201csomething you have\\u201d). This adds another step for your user, but that step is much easier for them than trying to create and remember yet another password.\\r\\n<\\/p>\\r\\n<h3>HELP YOUR USERS UNDERSTAND WHERE THEIR CONTENT IS BEING DISPLAYED<\\/h3>\\r\\n<p>Most people are unaware of how sensitive the content they put onto the internet can be if that content isn\\u2019t used in the way they were expecting.\\r\\n<\\/p>\\r\\n<p>Something as innocuous as a vacation beach photo could be worth thousands to a thief who now knows that that user is away from home.\\r\\n<\\/p>\\r\\n<p>For victims of domestic abuse, the consequences can be far more dire. A person might be living in a different state and using a pseudonym, but it\\u2019s possible that a \\u201csuggested friend\\u201d algorithm could surface their profile to users they\\u2019re trying to hide from.\\r\\n<\\/p>\\r\\n<p>Make sure you provide your users with enough information to fully understand where and how the content they post is being shared.\\r\\n<\\/p>\\r\\n<p>Provide granular controls so that they are able to easily decide who can see what. It should be easy not only for someone to hide any information they don\\u2019t want shared, but also to block and report any sort of abusive or harassing behavior.\\r\\n<\\/p>\\r\\n<h3>USER-TEST YOUR INTERFACES TO FIND SECURITY LEAKS<\\/h3>\\r\\n<p>Even the best, most powerful privacy controls aren\\u2019t effective unless users understand how to use them and what the defaults are.\\r\\n<\\/p>\\r\\n<p>If your site or app is using a new type of interaction or technology, make sure to educate your users on exactly how it works. A few slides clearly showing some do\\u2019s and don\\u2019ts can go a long way in protecting someone from embarrassment.\\r\\n<\\/p>\\r\\n<p>Test your new features before releasing them to make sure that your users are interacting with the controls in the way you expected. Do they understand what the defaults are? If they want to hide a particular piece of personal information, are they able to do it?\\r\\n<\\/p>\\r\\n<h3>GOOD SECURITY DESIGN IS GREAT FOR BUSINESS<\\/h3>\\r\\n<p>Netflix, Hulu, and Spotify have all planned for usability design with security in mind in a way that isn\\u2019t immediately apparent. The family plans they offer are actually a security feature in that they reduce the number of people sharing an account&mdash;all by offering an option that only costs a little bit more while still offering individual logins. This individual login approach protects users from giving out a password they have probably used elsewhere. It also reduces the number of unregistered users on the service.\\r\\n<\\/p>\\r\\n<p>This is a huge benefit for both the business and their customers.\\r\\n<\\/p>\\r\\n<h3>PRACTICE DEFENSIVE DESIGN THINKING&mdash;AND MAKE IT EASY!<\\/h3>\\r\\n<p>Security doesn\\u2019t have to be a hurdle for users and can actually be part of a good user experience. There will always be unknowns when dealing with complex systems that use algorithms and machine learning, but practicing defensive design thinking can make the experience better for everyone.\\r\\n<\\/p>\\r\\n<p>Security is everyone\\u2019s responsibility, from the CEO all the way down to the end user.\\r\\n<\\/p>\\r\\n<ul><li><span class=\\\"fas fa-tag\\\"><\\/span>\\r\\n<\\/li><\\/ul>\",\"2\":\"\"}}','2018-08-22 03:39:57','2018-08-22 03:39:57','83c0ba3f-f75a-431e-954d-f2bb1bf01aa0'),(12,9,2,1,'en_us',2,'','{\"typeId\":\"2\",\"authorId\":\"1\",\"title\":\"Data Visualization, and Identifying The True Challenge Within The Question\",\"slug\":\"data-visualization-and-identifying-the-true-challenge-within-the-question\",\"postDate\":1534908240,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"1\":\"<p>It started when a developer on a client\\u2019s team approached me with a question: \\u201cHey, you know D3.js right? Could you help us visualize some data?\\u201d<\\/p>\\r\\n<p>\\u201cOf course,\\u201d I said. That\\u2019s one of the reasons they brought us in, after all! \\u201cWhat are you trying to achieve?\\u201d Asking one seemingly simple question was the difference between delivering the requested solution and implementing a solution that went beyond the request to expose even more useful information.\\r\\n<\\/p>\\r\\n<p>We were in the middle of reskinning a legacy application built in a tech stack from a bygone era. Most of the codebase was decades old; a gnarly, tangled rubber-band ball of dependencies&mdash;the epitome of what developers refer to as \\u201cspaghetti code,\\u201d full of bad practices.\\r\\n<\\/p>\\r\\n<p>One notable challenge affected us daily: there was no file naming convention, and often there were duplicate files in different folders, so no one knew where the definitive version of any particular asset resided without a lot of hunting and guessing. Every time a change was required, work started with spelunking into the code base&mdash;or even worse, searching the database. It was the proverbial haystack, and we were always looking for a hay-colored needle.\\r\\n<\\/p>\\r\\n<p>For this and other reasons, the client developer recognized what we were up against. Any development task inevitably led to the questions, &nbsp;\\u201cWhat is the risk of this change? What else will be affected?\\u201d\\r\\n<\\/p>\\r\\n<p>The team set out to make a spreadsheet of all the dependencies. File A depends on File B, File B depends on File D, etc. But once we had compiled all of that data, it still wasn\\u2019t useful to humans. That\\u2019s when I was asked, \\u201cYou know D3.js, right?\\u201d\\r\\n<\\/p>\\r\\n<p>D3.js is a JavaScript-based data visualization library that we leverage on a fairly regular basis. The hope was that I could visualize all these dependencies&mdash;about 3,519 of them&mdash;to paint a picture of what we already knew for the rest of the organization: things were a mess.\\r\\n<\\/p>\\r\\n<p>The pivotal moment came from a seemingly simple question. Before just following orders, I asked, \\u201cWhat are you trying to achieve?\\u201d We spoke about what the data was, what sort of questions we\\u2019d want to answer, and I had an epiphany: D3 is a great tool for custom visualizations (and as in this case, is often requested\\/prescribed by the client at the outset), but like all tools, you need to know when to use it.\\r\\n<\\/p>\\r\\n<p>Some time ago, I was introduced to a tool called Neo4j, a&nbsp;<a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Graph_database\\\">Graph Database<\\/a>&nbsp;engine. I had barely tinkered with it, but I understood the general concept. Graph databases are primarily concerned with storing two things: nodes (\\u201cthings\\u201d) and relationships. Any point of data is a node, and how it relates to other nodes is, well, the relationship. Graph databases are perfect for asking questions about how things are related, and how relationships are shared.\\r\\n<\\/p>\\r\\n<p>So a graph database seemed like the direction to go: instead of a simple visualization generated after several hours of development, we had useful, pretty graphs we could query within minutes.\\r\\n<\\/p>\\r\\n<p>We could ask all kinds of questions: \\u201cWhat files have the most relationships? What files have no relationships? What files include ExampleFile.cfm?\\u201d Suddenly, we had a map. Because of the nature of Neo4j, we could easily add additional data as we wanted to ask more questions: \\u201cWhat files use this global variable? What files make direct database calls?\\u201d And as a bonus, all the visualizations are done with&hellip; you guessed it&hellip; D3, right out of the box.\\r\\n<\\/p>\\r\\n<p>Say we want to make a change that involves a particular file, but we need to know the impact it will have on the current codebase?\\r\\n<\\/p>\\r\\n<p><strong>We can ask Neo4j \\u201cHey, what files rely on \\u2018exampleFile.cfm\\u2019?\\u201d :<\\/strong>\\r\\n<\\/p>\\r\\n<p><img src=\\\"https:\\/\\/3vwizk2qtr8l3diwrm3r2ba0-wpengine.netdna-ssl.com\\/wp-content\\/uploads\\/2018\\/01\\/graphExample.gif\\\" style=\\\"display: block; margin-right: auto; margin-left: auto;\\\">\\r\\n<\\/p>\\r\\n<p><strong>Or \\u201cShow us all the relationships in our application\\u201d:<\\/strong>\\r\\n<\\/p>\\r\\n<p><img src=\\\"https:\\/\\/3vwizk2qtr8l3diwrm3r2ba0-wpengine.netdna-ssl.com\\/wp-content\\/uploads\\/2018\\/01\\/allGraph.gif\\\" style=\\\"display: block; margin-right: auto; margin-left: auto;\\\">\\r\\n<\\/p>\\r\\n<p>Instead of a static visualization, we have our data in a queryable format!\\r\\n<\\/p>\\r\\n<p>The most important thing I learned is to always get to the root of what the client is trying to do. \\u201cWhat are you trying to achieve?\\u201d is a powerful question, and can be the difference between a satisfactory outcome and a robust solution for the client. When exposed to the dev team at large, they were immediately inspired to ask more questions of the graph database. Instead of a good-enough tool, we leveraged a tool that got us even closer to making our case and solving the issue.\\r\\n<\\/p>\\r\\n<p>The whole journey was a good reminder: expand your horizons outside your discipline, and always look for the right problem to solve&mdash;not necessarily the literal question you\\u2019re presented with. This approach leads to solutions that exceed expectations.\\r\\n<\\/p>\\r\\n<ul><li><span class=\\\"fas fa-tag\\\"><\\/span>\\r\\n<\\/li><\\/ul>\",\"2\":\"\"}}','2018-08-22 03:40:27','2018-08-22 03:40:27','c8a40779-c2e4-4481-b9ab-f23cbfbeab49'),(13,9,2,1,'en_us',3,'','{\"typeId\":\"2\",\"authorId\":\"1\",\"title\":\"Data Visualization, and Identifying The True Challenge Within The Question\",\"slug\":\"data-visualization-and-identifying-the-true-challenge-within-the-question\",\"postDate\":1534908240,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"1\":\"<p>It started when a developer on a client\\u2019s team approached me with a question: \\u201cHey, you know D3.js right? Could you help us visualize some data?\\u201d<\\/p>\\r\\n<p>\\u201cOf course,\\u201d I said. That\\u2019s one of the reasons they brought us in, after all! \\u201cWhat are you trying to achieve?\\u201d Asking one seemingly simple question was the difference between delivering the requested solution and implementing a solution that went beyond the request to expose even more useful information.\\r\\n<\\/p>\\r\\n<p>We were in the middle of reskinning a legacy application built in a tech stack from a bygone era. Most of the codebase was decades old; a gnarly, tangled rubber-band ball of dependencies&mdash;the epitome of what developers refer to as \\u201cspaghetti code,\\u201d full of bad practices.\\r\\n<\\/p>\\r\\n<p>One notable challenge affected us daily: there was no file naming convention, and often there were duplicate files in different folders, so no one knew where the definitive version of any particular asset resided without a lot of hunting and guessing. Every time a change was required, work started with spelunking into the code base&mdash;or even worse, searching the database. It was the proverbial haystack, and we were always looking for a hay-colored needle.\\r\\n<\\/p>\\r\\n<p>For this and other reasons, the client developer recognized what we were up against. Any development task inevitably led to the questions, \\u201cWhat is the risk of this change? What else will be affected?\\u201d\\r\\n<\\/p>\\r\\n<p>The team set out to make a spreadsheet of all the dependencies. File A depends on File B, File B depends on File D, etc. But once we had compiled all of that data, it still wasn\\u2019t useful to humans. That\\u2019s when I was asked, \\u201cYou know D3.js, right?\\u201d\\r\\n<\\/p>\\r\\n<p>D3.js is a JavaScript-based data visualization library that we leverage on a fairly regular basis. The hope was that I could visualize all these dependencies&mdash;about 3,519 of them&mdash;to paint a picture of what we already knew for the rest of the organization: things were a mess.\\r\\n<\\/p>\\r\\n<p>The pivotal moment came from a seemingly simple question. Before just following orders, I asked, \\u201cWhat are you trying to achieve?\\u201d We spoke about what the data was, what sort of questions we\\u2019d want to answer, and I had an epiphany: D3 is a great tool for custom visualizations (and as in this case, is often requested\\/prescribed by the client at the outset), but like all tools, you need to know when to use it.\\r\\n<\\/p>\\r\\n<p>Some time ago, I was introduced to a tool called Neo4j, a <a href=\\\"https:\\/\\/en.wikipedia.org\\/wiki\\/Graph_database\\\">Graph Database<\\/a> engine. I had barely tinkered with it, but I understood the general concept. Graph databases are primarily concerned with storing two things: nodes (\\u201cthings\\u201d) and relationships. Any point of data is a node, and how it relates to other nodes is, well, the relationship. Graph databases are perfect for asking questions about how things are related, and how relationships are shared.\\r\\n<\\/p>\\r\\n<p>So a graph database seemed like the direction to go: instead of a simple visualization generated after several hours of development, we had useful, pretty graphs we could query within minutes.\\r\\n<\\/p>\\r\\n<p>We could ask all kinds of questions: \\u201cWhat files have the most relationships? What files have no relationships? What files include ExampleFile.cfm?\\u201d Suddenly, we had a map. Because of the nature of Neo4j, we could easily add additional data as we wanted to ask more questions: \\u201cWhat files use this global variable? What files make direct database calls?\\u201d And as a bonus, all the visualizations are done with&hellip; you guessed it&hellip; D3, right out of the box.\\r\\n<\\/p>\\r\\n<p>Say we want to make a change that involves a particular file, but we need to know the impact it will have on the current codebase?\\r\\n<\\/p>\\r\\n<p><strong>We can ask Neo4j \\u201cHey, what files rely on \\u2018exampleFile.cfm\\u2019?\\u201d :<\\/strong>\\r\\n<\\/p>\\r\\n<p><img src=\\\"https:\\/\\/3vwizk2qtr8l3diwrm3r2ba0-wpengine.netdna-ssl.com\\/wp-content\\/uploads\\/2018\\/01\\/graphExample.gif\\\" style=\\\"margin-right:auto;margin-left:auto;\\\" alt=\\\"graphExample.gif\\\"><\\/p>\\r\\n<p><strong>Or \\u201cShow us all the relationships in our application\\u201d:<\\/strong>\\r\\n<\\/p>\\r\\n<p><img src=\\\"https:\\/\\/3vwizk2qtr8l3diwrm3r2ba0-wpengine.netdna-ssl.com\\/wp-content\\/uploads\\/2018\\/01\\/allGraph.gif\\\" style=\\\"margin-right:auto;margin-left:auto;\\\" alt=\\\"allGraph.gif\\\"><\\/p>\\r\\n<p>Instead of a static visualization, we have our data in a queryable format!\\r\\n<\\/p>\\r\\n<p>The most important thing I learned is to always get to the root of what the client is trying to do. \\u201cWhat are you trying to achieve?\\u201d is a powerful question, and can be the difference between a satisfactory outcome and a robust solution for the client. When exposed to the dev team at large, they were immediately inspired to ask more questions of the graph database. Instead of a good-enough tool, we leveraged a tool that got us even closer to making our case and solving the issue.\\r\\n<\\/p>\\r\\n<p>The whole journey was a good reminder: expand your horizons outside your discipline, and always look for the right problem to solve&mdash;not necessarily the literal question you\\u2019re presented with. This approach leads to solutions that exceed expectations.<\\/p>\",\"2\":\"\"}}','2018-08-22 03:41:03','2018-08-22 03:41:03','7bdc04a5-9c6c-4d80-ba49-26f8957a13c3'),(14,8,2,1,'en_us',3,'','{\"typeId\":\"2\",\"authorId\":\"1\",\"title\":\"The Last Mile in Website Security: Usability\",\"slug\":\"the-last-mile-in-website-security-usability\",\"postDate\":1534908240,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"1\":\"<p>A thousand critical details go into making a website secure. But we often overlook the most critical piece of security: usability.<\\/p>\\r\\n<p>\\u201cSecurity at the expense of usability, comes at the expense of security.\\u201d \\u2013 AviD, user on Stack Exchange<\\/p>\\r\\n<p>Think about all the times you\\u2019ve seen someone write down their password and stick it on their monitor. If the best security is too hard to use, people will look for ways to bypass it. The best security is the security your users will actually use.<\\/p>\",\"2\":\"\"}}','2018-08-22 03:43:56','2018-08-22 03:43:56','920827e4-c837-47f1-a83b-ba79d9bbfa57'),(15,6,3,1,'en_us',2,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Urban Axes\",\"slug\":\"urban-axes\",\"postDate\":1534903980,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"3\":{\"date\":\"8\\/31\\/2018\"}}}','2018-08-24 01:01:31','2018-08-24 01:01:31','ea0aa76a-c288-48d9-9d81-f62092aa6cf7'),(16,5,3,1,'en_us',2,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"PWA Meetup\",\"slug\":\"pwa-meetup\",\"postDate\":1534903980,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"3\":{\"date\":\"8\\/31\\/2018\"}}}','2018-08-24 01:01:44','2018-08-24 01:01:44','ccb599fb-03b6-462d-9315-bca38199bebe'),(17,4,3,1,'en_us',2,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Cheese Day 2018\",\"slug\":\"cheese-day-2018\",\"postDate\":1534903920,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"3\":{\"date\":\"8\\/24\\/2018\"}}}','2018-08-24 01:02:23','2018-08-24 01:02:23','6361aee2-f5aa-468b-853b-4c3ba9223257'),(18,5,3,1,'en_us',3,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"PWA Meetup\",\"slug\":\"pwa-meetup\",\"postDate\":1534903980,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"3\":{\"date\":\"8\\/31\\/2018\"}}}','2018-08-24 01:05:36','2018-08-24 01:05:36','4f0b9c7e-1dd6-4093-8018-cfbedb7e5e9a'),(19,5,3,1,'en_us',4,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"PWA Meetup\",\"slug\":\"pwa-meetup\",\"postDate\":1534903980,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"123 Think Space\",\"3\":{\"date\":\"8\\/31\\/2018\"},\"4\":\"Think Space\"}}','2018-08-24 01:06:59','2018-08-24 01:06:59','5d74f9e1-7a28-470a-92d7-c0686b29c8dc'),(20,6,3,1,'en_us',3,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Urban Axes\",\"slug\":\"urban-axes\",\"postDate\":1534903980,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"123 Think Space\",\"3\":{\"date\":\"8\\/31\\/2018\"},\"4\":\"Think Space\"}}','2018-08-24 01:07:08','2018-08-24 01:07:08','0698e123-c87e-4b92-afc3-f7792feb96b7'),(21,4,3,1,'en_us',3,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Cheese Day 2018\",\"slug\":\"cheese-day-2018\",\"postDate\":1534903920,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"123 Think Space\",\"3\":{\"date\":\"8\\/24\\/2018\"},\"4\":\"Think Space\"}}','2018-08-24 01:07:18','2018-08-24 01:07:18','1856b353-0880-45ba-8e86-d29b8d5fcba6'),(22,5,3,1,'en_us',5,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"PWA Meetup\",\"slug\":\"pwa-meetup\",\"postDate\":1534903980,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"123 Think Space\",\"3\":{\"date\":\"8\\/31\\/2018\"},\"4\":\"Think Space\"}}','2018-08-24 01:07:27','2018-08-24 01:07:27','9d41438c-b75d-4a15-a04a-6d74bfcc740a'),(23,5,3,1,'en_us',6,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"PWA Meetup\",\"slug\":\"pwa-meetup\",\"postDate\":1534903980,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"123 Think Space\",\"3\":{\"date\":\"8\\/31\\/2018\",\"time\":\"1:00 AM\"},\"4\":\"Think Space\"}}','2018-08-24 01:12:36','2018-08-24 01:12:36','462d9cee-f362-4765-9697-9aa1f81bc2dd'),(24,6,3,1,'en_us',4,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Urban Axes\",\"slug\":\"urban-axes\",\"postDate\":1534903980,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"123 Think Space\",\"3\":{\"date\":\"8\\/31\\/2018\",\"time\":\"2:30 AM\"},\"4\":\"Think Space\"}}','2018-08-24 01:12:43','2018-08-24 01:12:43','51c59545-b1b1-4550-b40a-83881ecd72ce'),(25,4,3,1,'en_us',4,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Cheese Day 2018\",\"slug\":\"cheese-day-2018\",\"postDate\":1534903920,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"123 Think Space\",\"3\":{\"date\":\"8\\/24\\/2018\",\"time\":\"2:00 AM\"},\"4\":\"Think Space\"}}','2018-08-24 01:12:54','2018-08-24 01:12:54','c7be6ec4-5bb4-4c45-b3bd-0e72c1299791'),(26,5,3,1,'en_us',7,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"PWA Meetup\",\"slug\":\"pwa-meetup\",\"postDate\":1534903980,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"123 Think Space\",\"3\":{\"date\":\"8\\/31\\/2018\",\"time\":\"2:00 AM\"},\"4\":\"Think Space\"}}','2018-08-24 01:16:50','2018-08-24 01:16:50','1344a633-f4ce-476a-a844-36721501ceaf'),(27,6,3,1,'en_us',5,'','{\"typeId\":\"3\",\"authorId\":\"1\",\"title\":\"Urban Axes\",\"slug\":\"urban-axes\",\"postDate\":1534903980,\"expiryDate\":null,\"enabled\":1,\"parentId\":null,\"fields\":{\"5\":\"123 Think Space\",\"3\":{\"date\":\"8\\/31\\/2018\",\"time\":\"10:00 PM\"},\"4\":\"Think Space\"}}','2018-08-24 01:20:29','2018-08-24 01:20:29','118b52b6-bc23-4200-b5a2-d8092e773908');
/*!40000 ALTER TABLE `craft_entryversions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_fieldgroups`
--

DROP TABLE IF EXISTS `craft_fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fieldgroups_name_unq_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_fieldgroups`
--

LOCK TABLES `craft_fieldgroups` WRITE;
/*!40000 ALTER TABLE `craft_fieldgroups` DISABLE KEYS */;
INSERT INTO `craft_fieldgroups` VALUES (1,'Default','2018-08-20 21:51:10','2018-08-20 21:51:10','3e94e996-d0cf-41d0-ba4b-a0b0d820cfe0'),(3,'Events','2018-08-24 00:55:05','2018-08-24 00:55:05','5f082691-81ce-4e57-858a-9e00ff4f50b9');
/*!40000 ALTER TABLE `craft_fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_fieldlayoutfields`
--

DROP TABLE IF EXISTS `craft_fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fieldlayoutfields_layoutId_fieldId_unq_idx` (`layoutId`,`fieldId`),
  KEY `craft_fieldlayoutfields_sortOrder_idx` (`sortOrder`),
  KEY `craft_fieldlayoutfields_tabId_fk` (`tabId`),
  KEY `craft_fieldlayoutfields_fieldId_fk` (`fieldId`),
  CONSTRAINT `craft_fieldlayoutfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fieldlayoutfields_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fieldlayoutfields_tabId_fk` FOREIGN KEY (`tabId`) REFERENCES `craft_fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_fieldlayoutfields`
--

LOCK TABLES `craft_fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayoutfields` DISABLE KEYS */;
INSERT INTO `craft_fieldlayoutfields` VALUES (1,3,1,1,1,1,'2018-08-20 21:51:10','2018-08-20 21:51:10','ddfe452c-60a0-428b-bb5b-07cae7a2951a'),(2,5,2,1,1,1,'2018-08-20 21:51:10','2018-08-20 21:51:10','17d471cd-cb60-4b58-a19d-df278ad465a9'),(3,5,2,2,0,2,'2018-08-20 21:51:10','2018-08-20 21:51:10','64e7b454-3153-434e-815f-ac59c12be44a'),(5,8,4,3,0,1,'2018-08-24 01:06:28','2018-08-24 01:06:28','933ad8fe-3b16-4475-b702-1aead24efe2d'),(6,8,4,4,0,2,'2018-08-24 01:06:28','2018-08-24 01:06:28','ba6058ed-360e-47b6-8848-ae06df5db25d'),(7,8,4,5,0,3,'2018-08-24 01:06:28','2018-08-24 01:06:28','594c504e-3d37-4ae3-8c71-0af7d9122e14');
/*!40000 ALTER TABLE `craft_fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_fieldlayouts`
--

DROP TABLE IF EXISTS `craft_fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fieldlayouts_type_idx` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_fieldlayouts`
--

LOCK TABLES `craft_fieldlayouts` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayouts` DISABLE KEYS */;
INSERT INTO `craft_fieldlayouts` VALUES (1,'Tag','2018-08-20 21:51:10','2018-08-20 21:51:10','fb04bfcd-5d49-466e-b472-3d13eebbe5be'),(3,'Entry','2018-08-20 21:51:10','2018-08-20 21:51:10','7c45b6f8-4299-455c-a72b-4d918aa18e41'),(5,'Entry','2018-08-20 21:51:10','2018-08-20 21:51:10','3337f226-96eb-4461-8d22-177197b9a6ea'),(8,'Entry','2018-08-24 01:06:28','2018-08-24 01:06:28','fefc1dbb-6820-426b-891d-cf9da06fa3eb'),(9,'Entry','2018-08-24 01:25:58','2018-08-24 01:25:58','5f9e0cca-0172-4ded-a540-e44c70145411');
/*!40000 ALTER TABLE `craft_fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_fieldlayouttabs`
--

DROP TABLE IF EXISTS `craft_fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fieldlayouttabs_sortOrder_idx` (`sortOrder`),
  KEY `craft_fieldlayouttabs_layoutId_fk` (`layoutId`),
  CONSTRAINT `craft_fieldlayouttabs_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_fieldlayouttabs`
--

LOCK TABLES `craft_fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayouttabs` DISABLE KEYS */;
INSERT INTO `craft_fieldlayouttabs` VALUES (1,3,'Content',1,'2018-08-20 21:51:10','2018-08-20 21:51:10','18831591-5db5-453c-ad51-51a6e9e6d818'),(2,5,'Content',1,'2018-08-20 21:51:10','2018-08-20 21:51:10','1a89a849-d114-4ec6-86f0-76bb9ea3b1eb'),(4,8,'Events',1,'2018-08-24 01:06:28','2018-08-24 01:06:28','01bb887b-cd14-458c-9774-857f55b0dd1e');
/*!40000 ALTER TABLE `craft_fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_fields`
--

DROP TABLE IF EXISTS `craft_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(58) COLLATE utf8_unicode_ci NOT NULL,
  `context` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'global',
  `instructions` text COLLATE utf8_unicode_ci,
  `translatable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fields_handle_context_unq_idx` (`handle`,`context`),
  KEY `craft_fields_context_idx` (`context`),
  KEY `craft_fields_groupId_fk` (`groupId`),
  CONSTRAINT `craft_fields_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_fields`
--

LOCK TABLES `craft_fields` WRITE;
/*!40000 ALTER TABLE `craft_fields` DISABLE KEYS */;
INSERT INTO `craft_fields` VALUES (1,1,'Body','body','global',NULL,1,'RichText','{\"configFile\":\"Standard.json\",\"columnType\":\"text\"}','2018-08-20 21:51:10','2018-08-20 21:51:10','23d48d3d-7eb6-40a0-a7c7-901d11e10899'),(2,1,'Tags','tags','global',NULL,0,'Tags','{\"source\":\"taggroup:1\"}','2018-08-20 21:51:10','2018-08-20 21:51:10','5cf8b112-b213-4d99-afec-c83e933782ae'),(3,3,'Date','date','global','',0,'Date','{\"minuteIncrement\":\"30\",\"showTime\":1,\"showDate\":1}','2018-08-24 00:55:26','2018-08-24 01:12:23','8ba097cb-125c-4ecc-9abc-1cacab2433d9'),(4,3,'Location Name','locationName','global','',0,'PlainText','{\"placeholder\":\"\",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2018-08-24 01:04:02','2018-08-24 01:05:51','45d4a1c1-09cf-4259-b9e4-5358abacbed3'),(5,3,'Address','address','global','',0,'PlainText','{\"placeholder\":\"\",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2018-08-24 01:05:26','2018-08-24 01:05:56','fc1d595e-6788-44cb-93f7-d973841b0a67');
/*!40000 ALTER TABLE `craft_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_globalsets`
--

DROP TABLE IF EXISTS `craft_globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_globalsets` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int(10) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_globalsets_name_unq_idx` (`name`),
  UNIQUE KEY `craft_globalsets_handle_unq_idx` (`handle`),
  KEY `craft_globalsets_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_globalsets_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_globalsets_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_globalsets`
--

LOCK TABLES `craft_globalsets` WRITE;
/*!40000 ALTER TABLE `craft_globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_info`
--

DROP TABLE IF EXISTS `craft_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `schemaVersion` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `edition` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `siteName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `siteUrl` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timezone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `maintenance` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_info`
--

LOCK TABLES `craft_info` WRITE;
/*!40000 ALTER TABLE `craft_info` DISABLE KEYS */;
INSERT INTO `craft_info` VALUES (1,'2.7.0','2.6.14',0,'Think Company','http://localhost:8080/','UTC',1,0,'2018-08-20 21:51:08','2018-08-20 21:56:54','6c243f43-5b4e-4047-8148-a3f5981de125');
/*!40000 ALTER TABLE `craft_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_locales`
--

DROP TABLE IF EXISTS `craft_locales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_locales` (
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`locale`),
  KEY `craft_locales_sortOrder_idx` (`sortOrder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_locales`
--

LOCK TABLES `craft_locales` WRITE;
/*!40000 ALTER TABLE `craft_locales` DISABLE KEYS */;
INSERT INTO `craft_locales` VALUES ('en_us',1,'2018-08-20 21:51:08','2018-08-20 21:51:08','1d536de0-e677-4595-b067-f9b3176e821b');
/*!40000 ALTER TABLE `craft_locales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_matrixblocks`
--

DROP TABLE IF EXISTS `craft_matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `ownerLocale` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_matrixblocks_ownerId_idx` (`ownerId`),
  KEY `craft_matrixblocks_fieldId_idx` (`fieldId`),
  KEY `craft_matrixblocks_typeId_idx` (`typeId`),
  KEY `craft_matrixblocks_sortOrder_idx` (`sortOrder`),
  KEY `craft_matrixblocks_ownerLocale_fk` (`ownerLocale`),
  CONSTRAINT `craft_matrixblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_ownerLocale_fk` FOREIGN KEY (`ownerLocale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_matrixblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_matrixblocks`
--

LOCK TABLES `craft_matrixblocks` WRITE;
/*!40000 ALTER TABLE `craft_matrixblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_matrixblocktypes`
--

DROP TABLE IF EXISTS `craft_matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixblocktypes_name_fieldId_unq_idx` (`name`,`fieldId`),
  UNIQUE KEY `craft_matrixblocktypes_handle_fieldId_unq_idx` (`handle`,`fieldId`),
  KEY `craft_matrixblocktypes_fieldId_fk` (`fieldId`),
  KEY `craft_matrixblocktypes_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_matrixblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_matrixblocktypes`
--

LOCK TABLES `craft_matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `craft_matrixblocktypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_migrations`
--

DROP TABLE IF EXISTS `craft_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginId` int(11) DEFAULT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_migrations_version_unq_idx` (`version`),
  KEY `craft_migrations_pluginId_fk` (`pluginId`),
  CONSTRAINT `craft_migrations_pluginId_fk` FOREIGN KEY (`pluginId`) REFERENCES `craft_plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_migrations`
--

LOCK TABLES `craft_migrations` WRITE;
/*!40000 ALTER TABLE `craft_migrations` DISABLE KEYS */;
INSERT INTO `craft_migrations` VALUES (1,NULL,'m000000_000000_base','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','30f1f331-42c1-47d2-ae02-d5a344a0e5b1'),(2,NULL,'m140730_000001_add_filename_and_format_to_transformindex','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','a7efef73-8754-4d9e-8c47-7fdf436420de'),(3,NULL,'m140815_000001_add_format_to_transforms','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','0f6a2738-43ba-471f-b746-14d3e63c21a1'),(4,NULL,'m140822_000001_allow_more_than_128_items_per_field','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','bf678e1d-b891-47b6-9e35-1b3355ebbf7d'),(5,NULL,'m140829_000001_single_title_formats','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','a2d8ffe8-91bb-43ff-a83d-1fdda929bbd4'),(6,NULL,'m140831_000001_extended_cache_keys','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','c9ecb112-37f5-4d95-a4f5-61f9a728f3cd'),(7,NULL,'m140922_000001_delete_orphaned_matrix_blocks','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','0ad53baf-d885-443b-b1e4-ed27f3f8f91c'),(8,NULL,'m141008_000001_elements_index_tune','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','20bf67a9-204d-4aa5-b916-dd87f2801889'),(9,NULL,'m141009_000001_assets_source_handle','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','869f1f07-eca4-48b2-a146-19dc781a2d5c'),(10,NULL,'m141024_000001_field_layout_tabs','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','b2618897-d695-463c-9e4d-6a63fe126c46'),(11,NULL,'m141030_000000_plugin_schema_versions','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','7ae25533-cc67-4398-b2a7-02280843581c'),(12,NULL,'m141030_000001_drop_structure_move_permission','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','1fdce809-82da-4f00-8338-cbcf0580d972'),(13,NULL,'m141103_000001_tag_titles','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','36e4eacd-6bab-4ce8-8934-02afa17e2c0a'),(14,NULL,'m141109_000001_user_status_shuffle','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','4a26fb47-d0ad-46a2-b196-f682436473d6'),(15,NULL,'m141126_000001_user_week_start_day','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','5d1a69c8-9418-429e-90cb-dc68d09239b1'),(16,NULL,'m150210_000001_adjust_user_photo_size','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','8ff4538f-cb51-4680-88e5-65ecee12c219'),(17,NULL,'m150724_000001_adjust_quality_settings','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','957221cf-3b74-4feb-9ae5-9ef59ab1c415'),(18,NULL,'m150827_000000_element_index_settings','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','1f2adf00-dd3f-4b28-b936-2539217c3b86'),(19,NULL,'m150918_000001_add_colspan_to_widgets','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','e5a97b47-4343-47dd-bcb5-b25a110f220d'),(20,NULL,'m151007_000000_clear_asset_caches','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','4d63e36c-6062-4129-9a72-73662a2961e2'),(21,NULL,'m151109_000000_text_url_formats','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','5dd503fb-8d57-48db-a8bb-4df21a575559'),(22,NULL,'m151110_000000_move_logo','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','3a9a2259-c63d-438e-ba40-c44f46abe53a'),(23,NULL,'m151117_000000_adjust_image_widthheight','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','9df5ec90-36e1-49da-b6b2-ce00f68b95f7'),(24,NULL,'m151127_000000_clear_license_key_status','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','a6163a7f-2862-49ec-972a-a0c199e15b0c'),(25,NULL,'m151127_000000_plugin_license_keys','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','43596d28-98f0-4c86-b9d0-75c250e8d18c'),(26,NULL,'m151130_000000_update_pt_widget_feeds','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','e75dc3d9-854f-459c-8687-63c87176259f'),(27,NULL,'m160114_000000_asset_sources_public_url_default_true','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','37f81c68-6cbf-410a-bde6-c50cde11e61a'),(28,NULL,'m160223_000000_sortorder_to_smallint','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','712a2789-c012-47ee-8772-2ed15d47ecd2'),(29,NULL,'m160229_000000_set_default_entry_statuses','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','53a180a5-e61e-4356-8f43-a59e70859f8e'),(30,NULL,'m160304_000000_client_permissions','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','043ae849-6dc3-4721-8917-ec34b5cb8b73'),(31,NULL,'m160322_000000_asset_filesize','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','0192ff87-8f9b-4a84-94f8-6533adf476ff'),(32,NULL,'m160503_000000_orphaned_fieldlayouts','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','ff1e4686-f7ae-40d0-9b8d-8237f19d8906'),(33,NULL,'m160510_000000_tasksettings','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','80f6a743-826c-4209-8b6b-58f7834f4655'),(34,NULL,'m160829_000000_pending_user_content_cleanup','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','df6e92f7-3a0f-42a2-ab9a-2c23b2412f52'),(35,NULL,'m160830_000000_asset_index_uri_increase','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','b280e781-ad05-4649-bbf0-e8c983966f5e'),(36,NULL,'m160919_000000_usergroup_handle_title_unique','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','735012e2-ecc3-4750-8e7a-270c04fa2917'),(37,NULL,'m161108_000000_new_version_format','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','7fc75fa7-f569-4e40-a66d-2f7f54b80467'),(38,NULL,'m161109_000000_index_shuffle','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','bf03f5f0-57a9-40c6-9605-67c6a10238cb'),(39,NULL,'m170612_000000_route_index_shuffle','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','42563697-7b9a-49d9-bd30-1133c929b2c4'),(40,NULL,'m171107_000000_assign_group_permissions','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','8e6b100d-c24c-4df4-887e-c9cbae07107d'),(41,NULL,'m171117_000001_templatecache_index_tune','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','96d9f4f1-a928-4e3b-9ed6-0788807e2b07'),(42,NULL,'m171204_000001_templatecache_index_tune_deux','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','1bbe836a-ab6e-4b79-ab53-a2d3836fdfab'),(43,NULL,'m180406_000000_pro_upgrade','2018-08-20 21:51:08','2018-08-20 21:51:08','2018-08-20 21:51:08','d81d0ea5-d5d5-46c9-9dd8-faeb0f88a833');
/*!40000 ALTER TABLE `craft_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_plugins`
--

DROP TABLE IF EXISTS `craft_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `schemaVersion` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `licenseKey` char(24) COLLATE utf8_unicode_ci DEFAULT NULL,
  `licenseKeyStatus` enum('valid','invalid','mismatched','unknown') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unknown',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `settings` text COLLATE utf8_unicode_ci,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_plugins`
--

LOCK TABLES `craft_plugins` WRITE;
/*!40000 ALTER TABLE `craft_plugins` DISABLE KEYS */;
INSERT INTO `craft_plugins` VALUES (1,'Trimmer','1.0',NULL,NULL,'unknown',1,NULL,'2018-08-23 01:02:57','2018-08-23 01:02:57','2018-08-24 01:39:23','9f4c09d0-10ee-4e04-9f4e-58744bf9bd8b');
/*!40000 ALTER TABLE `craft_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_rackspaceaccess`
--

DROP TABLE IF EXISTS `craft_rackspaceaccess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_rackspaceaccess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `connectionKey` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `storageUrl` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cdnUrl` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_rackspaceaccess_connectionKey_unq_idx` (`connectionKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_rackspaceaccess`
--

LOCK TABLES `craft_rackspaceaccess` WRITE;
/*!40000 ALTER TABLE `craft_rackspaceaccess` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_rackspaceaccess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_relations`
--

DROP TABLE IF EXISTS `craft_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceLocale` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_relations_fieldId_sourceId_sourceLocale_targetId_unq_idx` (`fieldId`,`sourceId`,`sourceLocale`,`targetId`),
  KEY `craft_relations_sourceId_fk` (`sourceId`),
  KEY `craft_relations_sourceLocale_fk` (`sourceLocale`),
  KEY `craft_relations_targetId_fk` (`targetId`),
  CONSTRAINT `craft_relations_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_relations_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_relations_sourceLocale_fk` FOREIGN KEY (`sourceLocale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_relations_targetId_fk` FOREIGN KEY (`targetId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_relations`
--

LOCK TABLES `craft_relations` WRITE;
/*!40000 ALTER TABLE `craft_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_routes`
--

DROP TABLE IF EXISTS `craft_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locale` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `urlParts` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `urlPattern` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `template` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_routes_locale_idx` (`locale`),
  KEY `craft_routes_urlPattern_idx` (`urlPattern`),
  CONSTRAINT `craft_routes_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_routes`
--

LOCK TABLES `craft_routes` WRITE;
/*!40000 ALTER TABLE `craft_routes` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_searchindex`
--

DROP TABLE IF EXISTS `craft_searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `fieldId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`locale`),
  FULLTEXT KEY `craft_searchindex_keywords_idx` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_searchindex`
--

LOCK TABLES `craft_searchindex` WRITE;
/*!40000 ALTER TABLE `craft_searchindex` DISABLE KEYS */;
INSERT INTO `craft_searchindex` VALUES (1,'username',0,'en_us',' lukethink '),(1,'firstname',0,'en_us',''),(1,'lastname',0,'en_us',''),(1,'fullname',0,'en_us',''),(1,'email',0,'en_us',' luke pettway thinkbrownstone com '),(1,'slug',0,'en_us',''),(2,'slug',0,'en_us',' homepage '),(2,'title',0,'en_us',' welcome to localhost '),(2,'field',1,'en_us',' it s true this site doesn t have a whole lot of content yet but don t worry our web developers have just installed the cms and they re setting things up for the content editors this very moment soon localhost will be an oasis of fresh perspectives sharp analyses and astute opinions that will keep you coming back again and again '),(3,'field',1,'en_us',' craft is the cms that s powering localhost it s beautiful powerful flexible and easy to use and it s made by pixel tonic we can t wait to dive in and see what it s capable of this is even more captivating content which you couldn t see on the news index page because it was entered after a page break and the news index template only likes to show the content on the first page craft a nice alternative to word if you re making a website '),(3,'field',2,'en_us',''),(3,'slug',0,'en_us',' we just installed craft '),(3,'title',0,'en_us',' we just installed craft '),(4,'slug',0,'en_us',' cheese day 2018 '),(4,'title',0,'en_us',' cheese day 2018 '),(5,'slug',0,'en_us',' pwa meetup '),(5,'title',0,'en_us',' pwa meetup '),(6,'slug',0,'en_us',' urban axes '),(6,'title',0,'en_us',' urban axes '),(7,'field',1,'en_us',' with the release of the newest version of apple s ios a four year old technology called progressive web applications pwas just became an overnight success like the term ajax in 2005 the term progressive web application is a buzzword applied to a handful of new technologies specifically it s the way that web browsers on desktop and mobile devices will now grant their native application powers to websites chrome and firefox users on android and windows yes on the desktop have had access to these features for some time now that they ve been released to ios those progressive web application superpowers will quickly be everywhere and that means opportunities for you what can my site do once it s a progressive web app once your site is running over a secure connection and you ve added two pieces of code you can make your website available offline make your site run just as quickly over 4g as it does over wifi get your site onto users home screens without putting them through the app store process did we mention the app store process while you re at it you can save yourself the three weeks of hair pulling since you won t need app store approval do all of the above using a web tools using web skillsets on a web budget and a web timeline all managed in just one code base think how simple your trello boards will get soon pwas will be able to access bluetooth that will completely reshape how the internet of things works with the average user and that s just getting started sound interesting join us at the philly pwa meetup maybe you re a business stakeholder that wants to know how using progressive web apps can reduce the cost of developing applications maybe you re a product owner that dreams of releasing features with just one developer team instead of three and maybe you re a developer that wants to play with the big new box of toys that pwas provide please join us at the philly progressive web app meetup and let s explore what s possible together '),(7,'field',2,'en_us',''),(7,'slug',0,'en_us',' all your dreams came true overnight with progressive web applications '),(7,'title',0,'en_us',' all your dreams came true overnight with progressive web applications '),(8,'field',1,'en_us',' a thousand critical details go into making a website secure but we often overlook the most critical piece of security usability security at the expense of usability comes at the expense of security avid user on stack exchange think about all the times you ve seen someone write down their password and stick it on their monitor if the best security is too hard to use people will look for ways to bypass it the best security is the security your users will actually use '),(8,'field',2,'en_us',''),(8,'slug',0,'en_us',' the last mile in website security usability '),(8,'title',0,'en_us',' the last mile in website security usability '),(9,'field',1,'en_us',' it started when a developer on a client s team approached me with a question hey you know d3 js right could you help us visualize some data of course i said that s one of the reasons they brought us in after all what are you trying to achieve asking one seemingly simple question was the difference between delivering the requested solution and implementing a solution that went beyond the request to expose even more useful information we were in the middle of reskinning a legacy application built in a tech stack from a bygone era most of the codebase was decades old a gnarly tangled rubber band ball of dependencies the epitome of what developers refer to as spaghetti code full of bad practices one notable challenge affected us daily there was no file naming convention and often there were duplicate files in different folders so no one knew where the definitive version of any particular asset resided without a lot of hunting and guessing every time a change was required work started with spelunking into the code base or even worse searching the database it was the proverbial haystack and we were always looking for a hay colored needle for this and other reasons the client developer recognized what we were up against any development task inevitably led to the questions what is the risk of this change what else will be affected the team set out to make a spreadsheet of all the dependencies file a depends on file b file b depends on file d etc but once we had compiled all of that data it still wasn t useful to humans that s when i was asked you know d3 js right d3 js is a javascript based data visualization library that we leverage on a fairly regular basis the hope was that i could visualize all these dependencies about 3 519 of them to paint a picture of what we already knew for the rest of the organization things were a mess the pivotal moment came from a seemingly simple question before just following orders i asked what are you trying to achieve we spoke about what the data was what sort of questions we d want to answer and i had an epiphany d3 is a great tool for custom visualizations and as in this case is often requested prescribed by the client at the outset but like all tools you need to know when to use it some time ago i was introduced to a tool called neo4j a graph database engine i had barely tinkered with it but i understood the general concept graph databases are primarily concerned with storing two things nodes things and relationships any point of data is a node and how it relates to other nodes is well the relationship graph databases are perfect for asking questions about how things are related and how relationships are shared so a graph database seemed like the direction to go instead of a simple visualization generated after several hours of development we had useful pretty graphs we could query within minutes we could ask all kinds of questions what files have the most relationships what files have no relationships what files include examplefile cfm suddenly we had a map because of the nature of neo4j we could easily add additional data as we wanted to ask more questions what files use this global variable what files make direct database calls and as a bonus all the visualizations are done with you guessed it d3 right out of the box say we want to make a change that involves a particular file but we need to know the impact it will have on the current codebase we can ask neo4j hey what files rely on examplefile cfm or show us all the relationships in our application instead of a static visualization we have our data in a queryable format the most important thing i learned is to always get to the root of what the client is trying to do what are you trying to achieve is a powerful question and can be the difference between a satisfactory outcome and a robust solution for the client when exposed to the dev team at large they were immediately inspired to ask more questions of the graph database instead of a good enough tool we leveraged a tool that got us even closer to making our case and solving the issue the whole journey was a good reminder expand your horizons outside your discipline and always look for the right problem to solve not necessarily the literal question you re presented with this approach leads to solutions that exceed expectations '),(9,'field',2,'en_us',''),(9,'slug',0,'en_us',' data visualization and identifying the true challenge within the question '),(9,'title',0,'en_us',' data visualization and identifying the true challenge within the question '),(6,'field',3,'en_us',' 2018 08 31 '),(5,'field',3,'en_us',' 2018 08 31 '),(4,'field',3,'en_us',' 2018 08 24 '),(5,'field',4,'en_us',' think space '),(5,'field',5,'en_us',' 123 think space '),(6,'field',4,'en_us',' think space '),(6,'field',5,'en_us',' 123 think space '),(4,'field',4,'en_us',' think space '),(4,'field',5,'en_us',' 123 think space ');
/*!40000 ALTER TABLE `craft_searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_sections`
--

DROP TABLE IF EXISTS `craft_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('single','channel','structure') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'channel',
  `hasUrls` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `template` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enableVersioning` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_sections_name_unq_idx` (`name`),
  UNIQUE KEY `craft_sections_handle_unq_idx` (`handle`),
  KEY `craft_sections_structureId_fk` (`structureId`),
  CONSTRAINT `craft_sections_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_sections`
--

LOCK TABLES `craft_sections` WRITE;
/*!40000 ALTER TABLE `craft_sections` DISABLE KEYS */;
INSERT INTO `craft_sections` VALUES (1,NULL,'Home','homepage','single',1,'index',1,'2018-08-20 21:51:10','2018-08-23 01:30:08','2ee56bc4-c2c8-43e1-8c04-1acd71b38493'),(2,NULL,'News','news','channel',1,'news/_entry',1,'2018-08-20 21:51:10','2018-08-20 21:51:10','f6e10cd4-a8a5-44e1-ae35-ba9541d617e5'),(3,NULL,'Events','event','channel',1,'event/_entry',1,'2018-08-22 01:53:05','2018-08-23 01:25:47','a359e544-8ec0-47d8-bdd7-66a0d5e9d10f'),(4,1,'Employees','employees','structure',1,'employees/_entry',1,'2018-08-24 01:25:58','2018-08-24 01:25:58','fd5d9517-15a8-4021-b7a0-f1714d0519b0');
/*!40000 ALTER TABLE `craft_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_sections_i18n`
--

DROP TABLE IF EXISTS `craft_sections_i18n`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_sections_i18n` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `enabledByDefault` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `urlFormat` text COLLATE utf8_unicode_ci,
  `nestedUrlFormat` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_sections_i18n_sectionId_locale_unq_idx` (`sectionId`,`locale`),
  KEY `craft_sections_i18n_locale_fk` (`locale`),
  CONSTRAINT `craft_sections_i18n_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_sections_i18n_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_sections_i18n`
--

LOCK TABLES `craft_sections_i18n` WRITE;
/*!40000 ALTER TABLE `craft_sections_i18n` DISABLE KEYS */;
INSERT INTO `craft_sections_i18n` VALUES (1,1,'en_us',1,'__home__',NULL,'2018-08-20 21:51:10','2018-08-23 01:30:08','78206ac6-b847-451c-875d-aa55e3ca3145'),(2,2,'en_us',1,'news/{postDate.year}/{slug}',NULL,'2018-08-20 21:51:10','2018-08-20 21:51:10','2846434e-a7ef-406e-b494-5767f35f750d'),(3,3,'en_us',1,'event/{slug}',NULL,'2018-08-22 01:53:05','2018-08-22 01:53:05','b597a1c7-7999-47c8-bb98-206f41a77f85'),(4,4,'en_us',1,'employees/{slug}','{parent.uri}/{slug}','2018-08-24 01:25:58','2018-08-24 01:25:58','785dcbb1-34b7-4a79-9d0f-55da4d39b28d');
/*!40000 ALTER TABLE `craft_sections_i18n` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_sessions`
--

DROP TABLE IF EXISTS `craft_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_sessions_uid_idx` (`uid`),
  KEY `craft_sessions_token_idx` (`token`),
  KEY `craft_sessions_dateUpdated_idx` (`dateUpdated`),
  KEY `craft_sessions_userId_fk` (`userId`),
  CONSTRAINT `craft_sessions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_sessions`
--

LOCK TABLES `craft_sessions` WRITE;
/*!40000 ALTER TABLE `craft_sessions` DISABLE KEYS */;
INSERT INTO `craft_sessions` VALUES (1,1,'9ea39a7406a3357b4ae1990e2e7db812cb9b3fe7czozMjoic1ZXd1Q2NGtGSW1DMXU0ZjZSWVBRMWd5bklmOTBzVWwiOw==','2018-08-20 21:51:10','2018-08-20 21:51:10','edf2ed87-e207-4d85-9598-efdb2965f052'),(4,1,'89ffdbd4bb81b84962105be712dac1f249abedc4czozMjoiWk5pV0JSQmJrSVFnb1V1QnY4SUdpUHVkdTBQeFZNX2QiOw==','2018-08-22 01:43:38','2018-08-22 01:43:38','a616c4a0-7e36-44ed-9635-fcf58146116f'),(5,1,'86bbca74716a452baadf9f35ed0523de7c2fb471czozMjoiWlNKMzNpOVZqMmljN0RJZ3VheldWQUFWQWtBV2NUTlQiOw==','2018-08-23 00:58:05','2018-08-23 00:58:05','5c253507-c22a-4132-b338-8a7743129a25'),(6,1,'bd04a74e984d06cb7fdc48d82a5bfb62ab6dd4a4czozMjoiNlR6N290QkRWUXcxWUNkellHcHBhUDkwNTRMRkRkOFciOw==','2018-08-24 00:54:10','2018-08-24 00:54:10','d963c6d4-97a1-40e7-b818-ef7919bd2171');
/*!40000 ALTER TABLE `craft_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_shunnedmessages`
--

DROP TABLE IF EXISTS `craft_shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_shunnedmessages_userId_message_unq_idx` (`userId`,`message`),
  CONSTRAINT `craft_shunnedmessages_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_shunnedmessages`
--

LOCK TABLES `craft_shunnedmessages` WRITE;
/*!40000 ALTER TABLE `craft_shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_structureelements`
--

DROP TABLE IF EXISTS `craft_structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_structureelements_structureId_elementId_unq_idx` (`structureId`,`elementId`),
  KEY `craft_structureelements_root_idx` (`root`),
  KEY `craft_structureelements_lft_idx` (`lft`),
  KEY `craft_structureelements_rgt_idx` (`rgt`),
  KEY `craft_structureelements_level_idx` (`level`),
  KEY `craft_structureelements_elementId_fk` (`elementId`),
  CONSTRAINT `craft_structureelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_structureelements_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_structureelements`
--

LOCK TABLES `craft_structureelements` WRITE;
/*!40000 ALTER TABLE `craft_structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_structures`
--

DROP TABLE IF EXISTS `craft_structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_structures`
--

LOCK TABLES `craft_structures` WRITE;
/*!40000 ALTER TABLE `craft_structures` DISABLE KEYS */;
INSERT INTO `craft_structures` VALUES (1,2,'2018-08-24 01:25:58','2018-08-24 01:25:58','90f12621-697f-4736-a166-acab78efab30');
/*!40000 ALTER TABLE `craft_structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_systemsettings`
--

DROP TABLE IF EXISTS `craft_systemsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_systemsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_systemsettings_category_unq_idx` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_systemsettings`
--

LOCK TABLES `craft_systemsettings` WRITE;
/*!40000 ALTER TABLE `craft_systemsettings` DISABLE KEYS */;
INSERT INTO `craft_systemsettings` VALUES (1,'email','{\"protocol\":\"php\",\"emailAddress\":\"luke.pettway@thinkbrownstone.com\",\"senderName\":\"Think Company\"}','2018-08-20 21:51:10','2018-08-20 21:51:10','d3b9603f-e2a3-4d28-9380-82236526fefa');
/*!40000 ALTER TABLE `craft_systemsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_taggroups`
--

DROP TABLE IF EXISTS `craft_taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int(10) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_taggroups_name_unq_idx` (`name`),
  UNIQUE KEY `craft_taggroups_handle_unq_idx` (`handle`),
  KEY `craft_taggroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_taggroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_taggroups`
--

LOCK TABLES `craft_taggroups` WRITE;
/*!40000 ALTER TABLE `craft_taggroups` DISABLE KEYS */;
INSERT INTO `craft_taggroups` VALUES (1,'Default','default',1,'2018-08-20 21:51:10','2018-08-20 21:51:10','de64cb60-a5b1-4f12-ba0e-a781fd2c3c28');
/*!40000 ALTER TABLE `craft_taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_tags`
--

DROP TABLE IF EXISTS `craft_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_tags_groupId_fk` (`groupId`),
  CONSTRAINT `craft_tags_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_tags_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_tags`
--

LOCK TABLES `craft_tags` WRITE;
/*!40000 ALTER TABLE `craft_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_tasks`
--

DROP TABLE IF EXISTS `craft_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `currentStep` int(11) unsigned DEFAULT NULL,
  `totalSteps` int(11) unsigned DEFAULT NULL,
  `status` enum('pending','error','running') COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `settings` mediumtext COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_tasks_root_idx` (`root`),
  KEY `craft_tasks_lft_idx` (`lft`),
  KEY `craft_tasks_rgt_idx` (`rgt`),
  KEY `craft_tasks_level_idx` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_tasks`
--

LOCK TABLES `craft_tasks` WRITE;
/*!40000 ALTER TABLE `craft_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_templatecachecriteria`
--

DROP TABLE IF EXISTS `craft_templatecachecriteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_templatecachecriteria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `criteria` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_templatecachecriteria_cacheId_fk` (`cacheId`),
  KEY `craft_templatecachecriteria_type_idx` (`type`),
  CONSTRAINT `craft_templatecachecriteria_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_templatecachecriteria`
--

LOCK TABLES `craft_templatecachecriteria` WRITE;
/*!40000 ALTER TABLE `craft_templatecachecriteria` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_templatecachecriteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_templatecacheelements`
--

DROP TABLE IF EXISTS `craft_templatecacheelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_templatecacheelements` (
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  KEY `craft_templatecacheelements_cacheId_fk` (`cacheId`),
  KEY `craft_templatecacheelements_elementId_fk` (`elementId`),
  CONSTRAINT `craft_templatecacheelements_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_templatecacheelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_templatecacheelements`
--

LOCK TABLES `craft_templatecacheelements` WRITE;
/*!40000 ALTER TABLE `craft_templatecacheelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_templatecacheelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_templatecaches`
--

DROP TABLE IF EXISTS `craft_templatecaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheKey` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_templatecaches_cacheKey_locale_expiryDate_path_idx` (`cacheKey`,`locale`,`expiryDate`,`path`),
  KEY `craft_templatecaches_cacheKey_locale_expiryDate_idx` (`cacheKey`,`locale`,`expiryDate`),
  KEY `craft_templatecaches_locale_fk` (`locale`),
  CONSTRAINT `craft_templatecaches_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_templatecaches`
--

LOCK TABLES `craft_templatecaches` WRITE;
/*!40000 ALTER TABLE `craft_templatecaches` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_templatecaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_tokens`
--

DROP TABLE IF EXISTS `craft_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `route` text COLLATE utf8_unicode_ci,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_tokens_token_unq_idx` (`token`),
  KEY `craft_tokens_expiryDate_idx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_tokens`
--

LOCK TABLES `craft_tokens` WRITE;
/*!40000 ALTER TABLE `craft_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_usergroups`
--

DROP TABLE IF EXISTS `craft_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_usergroups_name_unq_idx` (`name`),
  UNIQUE KEY `craft_usergroups_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_usergroups`
--

LOCK TABLES `craft_usergroups` WRITE;
/*!40000 ALTER TABLE `craft_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_usergroups_users`
--

DROP TABLE IF EXISTS `craft_usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_usergroups_users_groupId_userId_unq_idx` (`groupId`,`userId`),
  KEY `craft_usergroups_users_userId_fk` (`userId`),
  CONSTRAINT `craft_usergroups_users_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_usergroups_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_usergroups_users`
--

LOCK TABLES `craft_usergroups_users` WRITE;
/*!40000 ALTER TABLE `craft_usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_userpermissions`
--

DROP TABLE IF EXISTS `craft_userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_userpermissions`
--

LOCK TABLES `craft_userpermissions` WRITE;
/*!40000 ALTER TABLE `craft_userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_userpermissions_usergroups`
--

DROP TABLE IF EXISTS `craft_userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_usergroups_permissionId_groupId_unq_idx` (`permissionId`,`groupId`),
  KEY `craft_userpermissions_usergroups_groupId_fk` (`groupId`),
  CONSTRAINT `craft_userpermissions_usergroups_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_userpermissions_usergroups_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_userpermissions_usergroups`
--

LOCK TABLES `craft_userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `craft_userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_userpermissions_users`
--

DROP TABLE IF EXISTS `craft_userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_users_permissionId_userId_unq_idx` (`permissionId`,`userId`),
  KEY `craft_userpermissions_users_userId_fk` (`userId`),
  CONSTRAINT `craft_userpermissions_users_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_userpermissions_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_userpermissions_users`
--

LOCK TABLES `craft_userpermissions_users` WRITE;
/*!40000 ALTER TABLE `craft_userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_users`
--

DROP TABLE IF EXISTS `craft_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` char(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preferredLocale` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weekStartDay` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `client` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `locked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `suspended` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pending` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `archived` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIPAddress` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(4) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `verificationCode` char(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passwordResetRequired` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_users_username_unq_idx` (`username`),
  UNIQUE KEY `craft_users_email_unq_idx` (`email`),
  KEY `craft_users_verificationCode_idx` (`verificationCode`),
  KEY `craft_users_uid_idx` (`uid`),
  KEY `craft_users_preferredLocale_fk` (`preferredLocale`),
  CONSTRAINT `craft_users_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_users_preferredLocale_fk` FOREIGN KEY (`preferredLocale`) REFERENCES `craft_locales` (`locale`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_users`
--

LOCK TABLES `craft_users` WRITE;
/*!40000 ALTER TABLE `craft_users` DISABLE KEYS */;
INSERT INTO `craft_users` VALUES (1,'lukethink',NULL,NULL,NULL,'luke.pettway@thinkbrownstone.com','$2y$13$hrzgFK0WtVTWsMbu/Rz4d.bhl4u1A6275DUI.WOccVE6ScFa48/ky',NULL,0,1,0,0,0,0,0,'2018-08-24 00:54:10','172.17.0.1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2018-08-20 21:51:09','2018-08-20 21:51:09','2018-08-24 00:54:10','33596eaf-74c9-49ec-b8cc-47656cc260e2');
/*!40000 ALTER TABLE `craft_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_widgets`
--

DROP TABLE IF EXISTS `craft_widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(4) unsigned DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_widgets_userId_fk` (`userId`),
  CONSTRAINT `craft_widgets_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_widgets`
--

LOCK TABLES `craft_widgets` WRITE;
/*!40000 ALTER TABLE `craft_widgets` DISABLE KEYS */;
INSERT INTO `craft_widgets` VALUES (1,1,'RecentEntries',1,NULL,NULL,1,'2018-08-20 21:51:12','2018-08-20 21:51:12','b265809a-023a-445a-9adc-ab2d70295692'),(2,1,'GetHelp',2,NULL,NULL,1,'2018-08-20 21:51:12','2018-08-20 21:51:12','7a4f3947-4b7f-458a-9975-bfba7ff61035'),(3,1,'Updates',3,NULL,NULL,1,'2018-08-20 21:51:12','2018-08-20 21:51:12','14649c81-2041-4a98-8888-bb6a1e933dd4'),(4,1,'Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\"}',1,'2018-08-20 21:51:12','2018-08-20 21:51:12','67c91dc1-6857-4f12-97e4-688add22e7cd');
/*!40000 ALTER TABLE `craft_widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-24  1:40:01
